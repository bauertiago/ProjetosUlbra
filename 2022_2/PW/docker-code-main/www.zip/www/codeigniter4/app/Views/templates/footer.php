                    
                </section>  
            </div>
        </div>  

        <footer class="p-3 text-white text-center">
            <h2>Meu rodapé</h2>
            <a href="<?=base_url('/admin')?>">Área Administrativa</a>
        </footer>
    
    </body>

</html>