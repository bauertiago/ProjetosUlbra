<?php

namespace App\Controllers\Admin;
use App\Models\ProductModel;
use App\Controllers\BaseController;

class Product extends BaseController{

    public function listProducts(){
        $ProductModel = new ProductModel();
        $data = [
            'arrayProducts' => $ProductModel->findAll()
        ];
        echo view('admin/templates/header');
        echo view('admin/product/listProducts', $data);
        echo view('admin/templates/footer');
    }

    public function insertProduct(){
        echo view('admin/templates/header');
        echo view('admin/product/insertProduct');
        echo view('admin/templates/footer');
    }

    public function insertProductAction(){
        $data = [
            'name'=> $this -> request -> getVar('name'),
            'price'=> $this -> request -> getVar('price'),
            'description'=> $this -> request -> getVar('description'),
            'idCategory'=> $this -> request -> getVar('idCategory')
        ];
        $ProductModel = new ProductModel();
        $ProductModel ->insert($data);
        return redirect()->to(base_url('admin/listProducts'));
    }
}