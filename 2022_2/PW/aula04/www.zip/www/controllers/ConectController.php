<?php

class ConectController{
    
    public function listClient(){
        require_once('views/templates/header.php');
        require_once('views/list/listClient.php');
        require_once('views/templates/footer.php');
    }
        
}