<?php

$sql = "SELECT * FROM listClient";
$result = $conn->query($sql);