                
            </section>  
        </div>
    </div>  

    <footer class="p-3 bg-primary text-white text-center">
        <h2>Meu rodapé</h2>
    </footer>
   
</body>

</html>