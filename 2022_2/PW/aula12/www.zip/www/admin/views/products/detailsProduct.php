<h1>detalhes do produto</h1>
<table class="table">
    <tr>
        <th>Código do produto</th>
        <td>
            <?=$arrayProducts['idProduct']?>
        </td>
    </tr>
    <tr>
        <th>Nome</th>
        <td>
            <?=$arrayProducts['name']?>
        </td>
    </tr>
    <tr>
        <th>Preço</th>
        <td>
            <?=$arrayProducts['price']?>
        </td>
    </tr>
    <tr>
        <th>Descrição</th>
        <td>
            <?=$arrayProducts['description']?>
        </td>
    </tr>
    <tr>
        <th>Código Categoria</th>
        <td>
            <?=$arrayProducts['idCategory']?>
        </td>
    </tr>
   </table>