#include <stdio.h>
int main(){
    int i;
    for (i = 20; i >=0; i--)
    {
        printf("%d\n",i);
    }
    return 0;
}