function lerDados(){
    let base = parseInt(prompt("Digite o número base:"));
    let expoente = parseInt(prompt("Digite o expoente:"));

    return [base, expoente];
}

function calcular(){
   
    let [base, expoente] = lerDados();
    let resultado = Math.pow(base, expoente);
    console.log(base + "^" + expoente + "=" + resultado);
    alert(base + "^" + expoente + "=" + resultado);
}

calcular();